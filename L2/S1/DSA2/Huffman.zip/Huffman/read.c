#include "read.h"
#include <stdlib.h>

void writeBinaryFile(FILE *filename, int size, Huffchar tab[]){
	//save the size first in the file
	fwrite(&size,sizeof(int),1,filename);//putw(size,filename);
	//save the table of structures
	for(int i=0;i<size;i++)
		fwrite(&tab[i],sizeof(Huffchar),1,filename);
	//save the compressed text
}

char *readBinaryFile(FILE *filename){
	int num=getw(filename); //read the size of the number of characters
	printf("the number of characters is %d\n", num);//for testing
	//READ the alphabet of the compression
	Huffchar newch = {0,""};
	for(int i=0;i<num;i++){
		fread(&newch,sizeof(Huffchar),1,filename);
		printf("character %c: %s\n", newch.l,newch.bitstab);
	}
	//read the compressed text and translate
//	char c;
//	fread(&c,sizeof(char),1,filename);
//	printf("%c: ", c);

//	int array[8]; 
//	int *pi,i; pi=&i;*pi=0; 
//	while(!(feof)){
//		fread(&c,sizeof(char),1,filename);
//		int mask = 0x80;
//		while (mask>0) {
//			array[*pi] = (c & mask) > 0;
//			printf("%d", array[*pi]);
//			mask >>= 1;
//			(*pi)++;
//		}
//	}
}
