import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;

public class EssaiSwing6 implements ActionListener
{
	JPasswordField passwordField = new JPasswordField("");
	JPanel pannel = new JPanel();
	
	public static void main (String[] args)
	{
		new EssaiSwing6();
	}
	
	public EssaiSwing6()
	{
		JFrame f = new JFrame ("my window");
		f.setSize (300, 100);
		passwordField.setPreferredSize(new Dimension (100, 20));
		pannel.add(passwordField);
		JButton bouton = new JButton ("Display");
		bouton.addActionListener(this);
		pannel.add(bouton);
		f.getContentPane().add(pannel);
		f.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("Input Text = "+String.copyValueOf(passwordField.getPassword()));
	}	
}
