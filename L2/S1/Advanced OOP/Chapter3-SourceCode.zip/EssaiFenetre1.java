import java.awt.*;

public class EssaiFenetre1
{
	public static void main (String[] args)
	{
		Frame f = new Frame ("my window");
		Button b = new Button ("Hello");
		f.setBackground (Color.red);
		f.add(b);
		f.setVisible (true);
	}
}

