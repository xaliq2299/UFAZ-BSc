import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TestMenuSwing extends JMenuBar 
{
	public TestMenuSwing()
	{
		ActionListener afficherMenuListener = new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				System.out.println ("Used menu element ["+ event.getActionCommand()+"]");
			}
		};
		
		// creation of the menu
		JMenu fichierMenu = new JMenu("File"); 
		
		//creation and adding of the menu items
		JMenuItem item = new JMenuItem ("New", 'n');    // the 2nd parameter is a keybord shortcut
		item.addActionListener(afficherMenuListener); 	fichierMenu.add(item);
		item = new JMenuItem ("Open", 'o');
		item.addActionListener(afficherMenuListener); 	fichierMenu.add(item);
		item = new JMenuItem("Save", 's');
		item.addActionListener (afficherMenuListener); 	fichierMenu.add(item);
		fichierMenu.addSeparator();
		item = new JMenuItem("Quit");
		item.addActionListener(afficherMenuListener); 	fichierMenu.add (item);
		
		this.add(fichierMenu); //allows to integrate the menu in the menu bar
	}
	
}
