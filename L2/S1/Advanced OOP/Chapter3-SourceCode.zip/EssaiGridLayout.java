import java.awt.*;

public class EssaiGridLayout extends Frame
{
	private Button b1, b2, b3, b4, b5;
	
	public EssaiGridLayout()
	{
		this.setLayout(new  GridLayout( 2 , 3 ) );
		b1 = new Button ("1"); b2 = new Button ("2"); b3 = new Button ("3"); 
		b4 = new Button ("4"); b5 = new Button ("5");
		this.add (b1); this.add (b2); this.add (b3); 
		this.add (b4); this.add (b5); 
	}

	public static void main (String[] args)
	{
		EssaiGridLayout test = new EssaiGridLayout();
		test.pack();
		test.setVisible(true);
	}
}

