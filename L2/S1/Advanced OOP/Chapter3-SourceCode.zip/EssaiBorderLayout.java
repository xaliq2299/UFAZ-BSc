import java.awt.*;

public class EssaiBorderLayout extends Frame
{
	private Button b1, b2, b3, b4, b5;
	
	public EssaiBorderLayout()
	{
		// this.setLayout(new BorderLayout());  // default layout
		b1 = new Button ("north"); b2 = new Button ("south"); b3 = new Button ("east"); 
		b4 = new Button ("west"); b5 = new Button ("center");
		this.add (b1, BorderLayout.NORTH); this.add (b2, BorderLayout.SOUTH); 
		this.add (b3, BorderLayout.EAST); this.add (b4, BorderLayout.WEST); 
		this.add (b5, BorderLayout.CENTER); 
	}

	public static void main (String[] args)
	{
		EssaiBorderLayout test = new EssaiBorderLayout();
		test.pack();
		test.setVisible(true);
	}
}

