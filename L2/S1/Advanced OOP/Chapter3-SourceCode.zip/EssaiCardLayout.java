import java.awt.*;

public class EssaiCardLayout extends Frame
{
	private Button b1, b2, b3, b4, b5;
	
	public EssaiCardLayout()
	{
		this.setLayout(new  CardLayout() );
		b1 = new Button ("1"); b2 = new Button ("2"); b3 = new Button ("3"); 
		b4 = new Button ("4"); b5 = new Button ("5");
		this.add ("1st", b1); this.add ("2nd", b2); this.add ("3rd", b3); 
		this.add ("4th", b4); this.add ("5th", b5); 
	}

	public static void main (String[] args)
	{
		EssaiCardLayout test = new EssaiCardLayout();
		test.pack();
		test.setVisible(true);
	}
}

