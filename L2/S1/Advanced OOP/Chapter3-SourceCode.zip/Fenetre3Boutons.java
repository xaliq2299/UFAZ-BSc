import java.awt.*;

public class Fenetre3Boutons extends Frame
{
	public static final int WIDTH = 500;
	public static final int HEIGHT = 200;
	
	public Fenetre3Boutons (String title)
	{
			super (title);
			this.setSize(WIDTH, HEIGHT);
			this.setBackground(Color.RED);
			this.add(new Button ("bouton 1"));
			this.add(new Button ("bouton 2"));
			this.add(new Button ("bouton 3"));
			this.setVisible(true);
	}
}

