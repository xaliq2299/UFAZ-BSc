import javax.swing.JFrame;
import javax.swing.JButton;

public class EssaiSwing1 
{
	public static final int WIDTH = 300;
	public static final int HEIGHT = 200;
	
	public static void main (String[] args)
	{
		JFrame fenetre1 = new JFrame("Test Swing 1");
		fenetre1.setSize (WIDTH, HEIGHT);
		fenetre1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		JButton boutonFin = new JButton ("Cliquez ici pour terminer le programme");
		EcouteurDeFin boutonEcouteur = new EcouteurDeFin();
		boutonFin.addActionListener(boutonEcouteur);
		fenetre1.getContentPane().add(boutonFin);
		fenetre1.setVisible(true);
	}

}
