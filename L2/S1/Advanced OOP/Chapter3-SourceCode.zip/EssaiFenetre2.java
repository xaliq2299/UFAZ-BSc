import javax.swing.*;

public class EssaiFenetre2
{
	public static void main (String[] args)
	{
		JFrame f = new JFrame ("My second window");
		f.setVisible (true);
		// f.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	}
}

