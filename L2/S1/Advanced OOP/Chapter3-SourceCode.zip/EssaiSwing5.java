import javax.swing.*;

public class EssaiSwing5
{
	public static void main (String[] args)
	{
		JFrame f = new JFrame ("my window");
		f.setSize (600,200);
		JPanel panneau = new JPanel();
		JTextField textField = new JTextField ("my text");
		panneau.add(textField);
		f.getContentPane().add(panneau);
		f.setVisible(true);
	}
}


