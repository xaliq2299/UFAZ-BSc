import java.awt.*;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EssaiSwing4 extends JFrame
{
	public static void main (String[] args)
	{
		JFrame frame = new JFrame ("Menu Test");
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize (new Dimension (250, 200));
		
		TestMenuSwing menu = new TestMenuSwing();
		frame.setJMenuBar(menu); //allows to integrate the menu bar in the window
		
		frame.pack();
		frame.setVisible(true);
	}
}


 
