public class EssaiFenetre3Boutons
{
	public static void main (String[] args)
	{
		Fenetre3Boutons f = new Fenetre3Boutons 
			("where are the three buttons?");
	}
}
