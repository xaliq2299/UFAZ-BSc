import java.awt.*;

public class EssaiFlowLayout extends Frame
{
	private Button b1, b2, b3, b4, b5;
	
	public EssaiFlowLayout()
	{
		FlowLayout maLigne = new FlowLayout (FlowLayout.LEFT, 10, 10);
		this.setLayout(maLigne);
		b1 = new Button ("1"); b2 = new Button ("2"); b3 = new Button ("3"); 
		b4 = new Button ("4"); b5 = new Button ("5");
		this.add ("1st", b1); this.add ("2nd", b2); this.add ("3rd", b3); 
		this.add ("4th", b4); this.add ("5th", b5); 
	}

	public static void main (String[] args)
	{
		EssaiFlowLayout test = new EssaiFlowLayout();
		test.pack();
		test.setVisible(true);
	}
}
