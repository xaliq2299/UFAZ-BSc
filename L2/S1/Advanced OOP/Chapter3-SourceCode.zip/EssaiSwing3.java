import java.awt.*;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EssaiSwing3 extends JFrame implements ActionListener
{
	public static final int WIDTH = 300;
	public static final int HEIGHT = 200;
	public String m = "Cliquez pour changer";
	private int c=0;
	private JButton bouton;
	
	public static void main (String[] args)
	{
			EssaiSwing3 fenetre = new EssaiSwing3();
			fenetre.setVisible(true);
	}
	
	public EssaiSwing3()
	{
		super ("Essai Swing 3");
		this.setSize(WIDTH, HEIGHT);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bouton = new JButton (m);
		bouton.setBackground(Color.RED);
		bouton.addActionListener(this);
		this.setLayout (new BorderLayout());
		this.getContentPane().setBackground(Color.BLUE);
		this.getContentPane().add(bouton, BorderLayout.SOUTH);
	}
	
	public void actionPerformed (ActionEvent e)
	{
		getContentPane().setBackground(Color.RED);
		c+=1;
		if (c%2 ==0)
		{
			bouton.setText(m);
			getContentPane().setBackground(Color.PINK);
		}
		else
		{
			bouton.setText("Hello!");
			getContentPane().setBackground(Color.YELLOW);	
		}
	}
}
