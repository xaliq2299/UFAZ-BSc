import java.awt.Dimension;
import javax.swing.*;

public class EssaiSwing7
{
	public static void main (String[] args)
	{
		JFrame f = new JFrame ("my window");
		f.setSize(300, 100);
		JPanel pannel = new JPanel();
		JTextArea textArea = new JTextArea("");
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension (200, 70));
		pannel.add(scrollPane);
		f.getContentPane().add(pannel);
		f.setVisible(true);
	}
}

