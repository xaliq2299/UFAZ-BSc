public class TicTac 
{
	
	public static void main (String[] args) 
	{
				Thread tic = new TestThread ( "TIC" ) ;
				Thread tac = new TestThread( "TAC" ) ;
				tic.start();
				tac.start();
	}
}

