public class TestThread extends Thread
{
	private String s ;

	public TestThread (String s)
	{ 
		this.s=s ; 
	}
	

	public void run() 
	{
		while (true)
		{
				System.out.println(s);
				try {  sleep (100); } 
				catch (InterruptedException e)  {  }
        }
	}
}
