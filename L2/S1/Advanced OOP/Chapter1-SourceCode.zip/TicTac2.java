public class TicTac2 
{
	
	public static void main (String[] args) 
	{
				Thread tic = new Thread( new TestThread2 ( "TIC" )) ;
				Thread tac = new Thread (new TestThread2( "TAC" )) ;
				tic.start();
				tac.start();
	}
}

