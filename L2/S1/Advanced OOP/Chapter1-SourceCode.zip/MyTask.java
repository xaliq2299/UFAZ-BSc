public class MyTask {
	
	public static void main (String[] args) throws InterruptedException 
	{
		System.out.println (Thread.currentThread()) ;
		Thread initialTask = Thread.currentThread() ;
		initialTask.setName ("Initial Task");
		Thread.sleep (1000); //Sleep is a class method
		System.out.println (initialTask); 
		//the name of the thread has been changed, but not the name of its gorup
		System.out.println(initialTask.isAlive());
		Thread myTask = new Thread();
		myTask.setName("My Task");
		System.out.println(myTask);
		System.out.println(myTask.isAlive());
	}
}

