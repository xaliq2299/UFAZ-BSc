package miniProject;

import java.io.*;
import java.net.*;

/*
 *  A calculator server that supports multiple clients
 *  Listens on given port, establishes connection to clients
 *  and passes sockets to CalcServerThreads
 */

public class CalcServer {

    public static void main(String[] args){

        final int port = 3456;

        try(
                ServerSocket ss = new ServerSocket(port)
        )
        {

            // loop forever
            while(true){

                // accepts connections on ServerSocket and starts new CalcServerThread
                (new CalcServerThread(ss.accept())).start();

            }

        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}