package miniProject;

import java.io.*;
import java.net.*;

/*
 *  A client that connects to a CalcServer
 *  Send "exit" (without quotes) to end the connection
 *  Client by itself does not check nor sanitize input
 *  that will be sent to the server, all of that happens
 *  on server side
 */

public class CalcClient {

    public static void main(String[] args) {

        final int port = 3456;

        try(
                Socket socket = new Socket(InetAddress.getLocalHost(), port);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in))
        )
        {

            // the expression that it reads from stdin
            String inputExpr;

            // continuously read from stdin
            while((inputExpr = stdin.readLine()) != null){

                // send the expression to the server
                out.println(inputExpr);
                System.out.println("SENT");

                // receive server's reply and print it
                String reply = in.readLine();
                System.out.println("RESULT: "+reply);

                // if server is responding to out exit command, close everything
                if(reply.equalsIgnoreCase("exiting")){
                    in.close();
                    out.close();
                    socket.close();
                    System.out.println("Connection ended");
                    break;
                }
            }

        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
