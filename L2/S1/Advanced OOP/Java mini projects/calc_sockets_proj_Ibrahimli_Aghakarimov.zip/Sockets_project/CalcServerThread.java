package miniProject;

import java.io.*;
import java.net.*;

/*
 *  A thread that handles a client. Gets a socket from CalcServer,
 *  and manages any further communication with the client.
 */

public class CalcServerThread extends Thread {

    private Socket socket = null;

    // CalcServer accept()s a connection and passes socket to constructor
    public CalcServerThread(Socket socket){
        super("TestServerThread");
        this.socket = socket;
    }


    // evaluates a given expression, returns -1 if something's wrong
    private int evaluateExpression(String expr){

        // trim leading spaces, then split the string using whitespace as separator.
        // we assume operands and the operator are separated by space, the number of spaces doesn't matter
        String[] splitStr = expr.trim().split("\\s+");

        // ex: expr is " 5 - 3"
        // after trimming and splitting splitStr will contain:
        // splitStr[0] = "5"
        // splitStr[1] = "-"
        // splitStr[2] = "3"

        int operand1, operand2;

        // valid input must necessarily contain only 3 tokens
        // and the operator must be a single char
        if(splitStr.length == 3 && splitStr[1].length() == 1){

            // converting operands to ints
            try {
                operand1 = Integer.parseInt(splitStr[0]);
                operand2 = Integer.parseInt(splitStr[2]);
            }
            catch (NumberFormatException e){
                // NumberFormatException is thrown if inputs contain a decimal point, etc
                // and implies their invalidity
                return -1;
            }

            // operation will contain single char anyways
            char operation = splitStr[1].charAt(0);

            // print the extracted tokens on the server console
            System.out.println("op1: "+operand1+", op2 = "+operand2+", op = "+operation);

            // result of the expression
            int result;

            // check if both operands aren't negative
            if( operand1 >= 0 && operand2 >= 0){
                // perform the operation
                switch(operation){
                    case '+': result = operand1+operand2; break;

                    case '-': result = operand1-operand2; break;

                    case '*': result = operand1*operand2; break;

                    // checking for division by zero
                    case '/': if(operand2 == 0)  return -1;
                              result = operand1/operand2; break;

                    default: return -1;
                }
                // the result must not be negative
                if (result >= 0) return result;

            }
        }

        return -1;

    }


    public void run(){

        try(
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        )
        {

            System.out.println("A new client connected");

            String inputLine;
            int result;

            // continuously read from the socket's input stream
            while((inputLine = in.readLine()) != null){

                // client can send "exit" (without quotes) to end the connection
                if(inputLine.equalsIgnoreCase("exit")){

                    // notify the client that connection is closing indeed
                    out.println("exiting");

                    System.out.println("A client disconnected");
                    break;
                }

                // prepare the result
                result = evaluateExpression(inputLine);

                // send result to the client
                out.println(result);

            }

            // close the socket after we are done
            socket.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

}
