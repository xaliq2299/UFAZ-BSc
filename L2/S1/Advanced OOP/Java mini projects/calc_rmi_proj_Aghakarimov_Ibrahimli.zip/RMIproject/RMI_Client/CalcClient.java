import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.registry.*;

public class CalcClient  {

    private CalcClient() {}

    public static void main(String[] args) {

        try {
            // retrieve the registry
            Registry registry = LocateRegistry.getRegistry(1337);
            
            // query the registry to get the stub
            CalcService stub = (CalcService) registry.lookup("Calculate");

            // we will read the expression from standard input
            String expr;
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

            // read the expression
            while((expr = stdin.readLine()) != null) {
                // evaluate the result remotely and print the result
                System.out.println("Result = "+stub.evaluateExpression(expr));
            }

        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }

}
