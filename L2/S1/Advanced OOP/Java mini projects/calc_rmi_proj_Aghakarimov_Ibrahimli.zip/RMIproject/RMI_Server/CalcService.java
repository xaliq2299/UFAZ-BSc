/*
 *  A service that evaluates an expression given as a string,
 *  and returns the result as an integer.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalcService extends Remote {

    // evaluates a given expression, returns -1 if something's wrong
    int evaluateExpression(String expr) throws RemoteException;

}
