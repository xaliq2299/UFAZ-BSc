/*
 *  A server that announces its calculation service to a rmiregistry
 *  (registry running on port 1337),  and calculates expressions
 */

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalcServer {

    public CalcServer(){}

    public static void main(String args[]){

        // had to put this line in order for Java to recognize our security.policy file
        System.setProperty("java.security.policy","file:./security.policy");

        try {
            // setting a security manager
            System.setSecurityManager(new SecurityManager());

            // creating the remote object
            CalcServiceImpl stub = new CalcServiceImpl();

            // getting the registry
            Registry registry = LocateRegistry.getRegistry(1337);

            // exporting the object under the name "Calculate"
            registry.rebind("Calculate", stub);

            System.out.println("Server is ready");
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }
}
