
/*
 *  A counter that will count until n with random pauses in range [0, 5] seconds in-between
 *  Displays its name each iteration, and an end message when it's done
 */

public class Counter extends Thread{

    private String name;
    private int n;

    // name will be printed with each increment, increments go until n
    public Counter(String name, int n){
        this.name = name;
        this.n = n;
    }

    @Override
    public void run(){

        // we lock stdout until we are finished, so that this counter can count uninterrupted
        synchronized (System.out) {

            for (int cur = 1; cur <= n; cur++) {

                // pausing for [0, 5000] milliseconds
                long to_sleep = (long) (Math.random() * 5000);

                try {
                    Thread.sleep(to_sleep);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // printing current number
                System.out.println(this.name + " : " + cur);

            }

            // the end message
            System.out.println("end of " + this.name);

        }
    }

}

