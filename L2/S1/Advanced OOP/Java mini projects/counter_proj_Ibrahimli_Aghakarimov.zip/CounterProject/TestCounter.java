public class TestCounter {

    public static void main(String[] args) throws InterruptedException{

        Counter c1 = new Counter("Counter1", 3);
        Counter c2 = new Counter("Counter2", 5);
        Counter c3 = new Counter("Counter3", 4);

        // starting all of the threads and joining them in order of their arrival

        c1.start();
        c1.join();
        c2.start();
        c2.join();
        c3.start();
        c3.join();
    }
}