
import javax.swing.*;
import java.awt.*;

public class DisplayGraphics extends JPanel{

    private Timer timer;              // to keep track of color changes
    private long time = 0;            // the time
    private long green_time = 500;    // time thread is green after receiving/sending a message
    private long initial_delay = 2000; // freeze time before round

    // sleep times of threads
    private long[] t_sleep_times = new long[5];

    private static int t_gap = 80;   // horizontal gap between thread ellipses
    private static int b_gap = 80;   // horizontal gap between buffer ellipses
    private static int h_gap = 55;   // vertical gap between two rows of ellipses

    private int[] t_oval_xs = new int[5];  // coordinates of thread ellipses
    private int t_oval_y = 60 + h_gap + 20;

    private String[] t_labels = {"ST", "IT1", "IT2", "IT3", "WT"};  // names of threads

    private int[] b_oval_xs = new int[4];  // coordinates of buffer ellipses
    private int b_oval_y = t_oval_y + e_h + h_gap;

    private boolean[] b_contains_message = {false, false, false, false};  // buffer is empty or not

    private static int INFO_x = 130;   // info text coordinates
    private static int INFO_y = 40;

    private static int e_w = 80;        // ellipse width
    private static int e_h = 60;        // ellipse height

    private static Color t_not_active = new Color(184, 176, 160);    // threads start with this color
    private static Color t_transmitting = new Color(0, 255, 0);   // thread is sending something (lasts 1 second)
    private static Color t_sleeping = new Color(255, 255, 0);     // thread is sleeping

    private static Color b_not_active = new Color(100, 100, 100);    // buffers start with this color
    private static Color b_full = new Color(255, 51, 153);            // buffer contains a message

    public DisplayGraphics(){

        // set double buffering on
        super(true);

        // initializing coordinates of ellipses
        for(int i=0; i<5; i++) t_oval_xs[i] = 40 + (e_w + t_gap)*i;
        for(int i=0; i<4; i++) b_oval_xs[i] = 120 + (e_w + b_gap)*i;

        for(int i=0; i<t_sleep_times.length; i++) t_sleep_times[i] = (long)(Math.random()*2000);

        // initializing the timer (everything is based on it)
        timer = new Timer(1, e -> {time += 1; repaint();});
        timer.setRepeats(true);
        timer.setInitialDelay(0);
        timer.start();
    }

//    void drawDashedArrow(Graphics g, int start_x, int start_y, int end_x, int end_y){
//        // to get a thicker line we draw multiple lines (t=vertical pixel offset of line)
//        int dist = 6, thickness = 3;
//        for(int t=0; t<thickness; t++) {
//            for (int i = start_x; i <= end_x; i += 2 * dist) g.drawLine(i, start_y+t, i + dist, end_y+t);
//        }
//    }

    void drawDashedArrow(Graphics g, int start_x, int start_y, int end_x, int end_y){
        int dist = 6;
        ((Graphics2D)g).setStroke(new BasicStroke(3));
        for (int i = start_x; i <= end_x; i += 2 * dist) g.drawLine(i, start_y, i + dist, end_y);
        ((Graphics2D)g).setStroke(new BasicStroke(1));
    }

    void drawArrow(Graphics g, int start_x, int start_y, int end_x, int end_y, boolean isDown){
        // to get a thicker line we draw multiple lines (t=vertical pixel offset of line)
        int shift_x1=10, shift_y1=5, shift_x2=4, shift_y2=7;

        ((Graphics2D)g).setStroke(new BasicStroke(3));

        g.drawLine(start_x, start_y, end_x, end_y);
        
/*        if(isDown) {
            g.drawLine(end_x - shift_x1, end_y - shift_y1, end_x, end_y);
            g.drawLine(end_x + shift_x2, end_y - shift_y2, end_x, end_y);
        }
        else {
            g.drawLine(end_x - shift_x1, end_y + shift_y1, end_x, end_y);
            g.drawLine(end_x + shift_x2, end_y + shift_y2, end_x, end_y);
        }*/
        ((Graphics2D)g).setStroke(new BasicStroke(1));
    }

    @Override
    public void paintComponent(Graphics g){

        setBackground(Color.WHITE);
        g.setFont(new Font("Serif", Font.PLAIN, 20));

        // general information displayed on top
        g.drawString("Each of the threads sleeps for a random period of up to",INFO_x, INFO_y);
        g.drawString("   2 seconds when they receive or transmit a message", INFO_x, INFO_y+30);

        // drawing threads
        for(int i=0; i<5; i++) {

            long t = initial_delay;    // time since this thread received the message
            for(int j=0; j<i; j++) t += t_sleep_times[j] + 2*green_time;
            t = time - t;

            // determining in what state we are based on the elapsed time since current thread received the message
            if(0<t && t<green_time){
                g.setColor(t_transmitting);
                if(i != 0) b_contains_message[i-1] = true;
            }
            else if(green_time < t && t< green_time + t_sleep_times[i]){
                g.setColor(t_sleeping);
            }
            else if(green_time + t_sleep_times[i] < t && t < green_time*2 + t_sleep_times[i]){
                g.setColor(t_transmitting);
                if(i != 0) b_contains_message[i-1] = false;
            }
            else g.setColor(t_not_active);

            g.fillOval(t_oval_xs[i], t_oval_y, e_w, e_h);
            if(i != 4) drawDashedArrow(g, t_oval_xs[i] + e_w, t_oval_y + e_h/2, t_oval_xs[i+1], t_oval_y + e_h/2);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Serif", Font.BOLD, 20));
            g.drawString(t_labels[i], t_oval_xs[i] + e_w/2 - 15, t_oval_y + e_h/2 + 7);
        }

        // drawing buffers
        for(int i=0; i<4; i++) {
            // determining whether buffer contains a message
            if(b_contains_message[i]) g.setColor(b_full);
            else g.setColor(b_not_active);

            g.fillOval(b_oval_xs[i], b_oval_y, e_w, e_h);
            drawArrow(g, b_oval_xs[i]+5-e_w/2, t_oval_y+e_h,b_oval_xs[i]+5, b_oval_y+10, true);
            drawArrow(g,b_oval_xs[i]+e_w-5, b_oval_y+10, b_oval_xs[i]+3*e_w/2, t_oval_y+e_h, false);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Serif", Font.BOLD, 20));
            g.drawString("B"+(i+1), b_oval_xs[i] + e_w/2 - 15, b_oval_y + e_h/2 + 7);
        }
    }
}
